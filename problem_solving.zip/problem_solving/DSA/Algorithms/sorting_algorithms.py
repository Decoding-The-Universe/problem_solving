array = [3, 5, 1, 7, 2, 8, 9, 11, 15, 55, 67, 88, 90, 33]

def quicksort_main_helper(a, l, h):
    if l < h:
        r = partition(a, l, h)
        quicksort_main_helper(a, l, r)
        quicksort_main_helper(a, r+1, h)

def partition(a, l, r):
    p = l
    piviot = a[p]
#    left_pointer = l+1
#   right_pointer = r
    while(l<=r):
        while piviot >= a[l] and l<=r:
            l+=1
        while piviot < a[r] and l<=r:
            r-=1
        if l<r:
            switch(a, l, r)
    switch(a, p, r)
    return r

def switch(a, x, y):
    e1 = a[x]
    e2 = a[y]
    a[x] = e2
    a[y] = e1

def quicksort(a):
    quicksort_main_helper(a, 0, int(len(a)-1))
    return a

#print(quicksort(array))

def mergesort_helper(a, l, r):
    if l<r:
        m = (l+r)//2
        mergesort_helper(a, l, m)
        mergesort_helper(a, m+1, r)
        return merge(a, l, m, r)


def merge(a, l, m, r):
    b = []
    bcount = 0
    left_pointer = l
    right_pointer = m+1
    while left_pointer!=m+1 and right_pointer!=r+1:
        if a[left_pointer] <= a[right_pointer]:
            b.append(a[left_pointer])
            left_pointer = left_pointer+1
            bcount+=1
        else:
            b.append(a[right_pointer])
            right_pointer = right_pointer+1
            bcount+=1
    if left_pointer == m+1:
        for i in range(right_pointer, r+1):
            b.append(a[i])
            bcount+=1
    else:
        for j in range(left_pointer, m+1):
            b.append(a[j])
            bcount+=1
    for B in range(l, r+1):
        a[B] = b[B-l]

def mergesort(a):
    mergesort_helper(a, 0, int(len(a)-1))
    return a

print(quicksort(array))
