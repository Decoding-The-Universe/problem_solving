import math

soduku = [[5, 3, 0, 0, 7, 0, 0, 0, 0],
          [6, 0, 0, 1, 9, 5, 0, 0, 0],
          [0, 9, 8, 0, 0, 0, 0, 6, 0],
          [8, 0, 0, 0, 6, 0, 0, 0, 3],
          [4, 0, 0, 8, 0, 3, 0, 0, 1],
          [7, 0, 0, 0, 2, 0, 0, 0, 6],
          [0, 6, 0, 0, 0, 0, 2, 8, 0],
          [0, 0, 0, 4, 1, 9, 0, 0, 5],
          [0, 0, 0, 0, 8, 0, 0, 7, 9]]

def soduku_printer(soduku):
    for i in range(9):
        if i%3 == 0 and i!= 0:
            print('- - - - - - - - - - - - - - - -')
        for j in range(9):
            if j%3 == 0 and j != 0:
                print('|', end="")
            if j ==8:
                print(' ' + str(soduku[i][j]) + ' ')
            else:
                print(' ' + str(soduku[i][j]) + ' ', end="")

# we are only printing in the form of strings but they are stored in the form of integers
soduku_printer(soduku)

empty = []

def find_empty(soduku):
    for i in range(9):
        for j in range(9):
            if soduku[i][j] == 0:
                empty.append((i, j))

def actual_checker(i, j):
    for element in range(1, 10):
        if row_checker(i, j, element) == True and column_checker(i, j, element) == True and box_checker(i, j, element) == True:
            soduku[i][j] = element
            return True
    return False

def row_checker(x, y, element):
    state = True
    for j in range(9):
        if j != y:
            if soduku[x][j] == element:
                state = False
                break
            else:
                state = state
        else:
            continue
    return state

def column_checker(x, y, element):
    state = True
    for i in range(9):
        if i != x:
            if soduku[i][y] == element:
                state = False
                break
            else:
                state = state
        else:
            continue
    return state
def box_checker(x, y, element):
    state = True
    ix = math.floor(x/3)
    jy = math.floor(y/3)
    for i in range(3*ix, 3*ix+3):
        for j in range(3*jy, 3*jy+3):
            if (i, j) == (x, y):
                continue
            else:
                if soduku[i][j] == element:
                    state = False
                else:
                    continue
    return state

l = 0

def backprop(pos):
    i, j = empty[pos]
    element = soduku[i][j]
    for k in range(9):
        if element<9:
            element+=1
            if row_checker(i, j, element) == True and column_checker(i, j, element) == True and box_checker(i, j, element) == True:
                soduku[i][j] = element
                break
            else:
                continue
    else:
        soduku[i][j] = 0
        pos = pos - 1
        pos = backprop(pos)
    return pos
find_empty(soduku)

loop = 0
while l != int(len(empty)):
    #print(l)
    x, y = empty[l]
    state = actual_checker(x, y)
    if state == True:
        loop += 1
    if state == False:
        loop += 1
        l = backprop(l - 1)

    l+=1

def valid(bo, num, pos):
    i, j = pos
    element = num
    if row_checker(i, j, element) == True and column_checker(i, j, element) == True and box_checker(i, j,element) == True:
        return True
    return False



print(' - - - - - - - - - -- - - -- - - - - - - - - - ')
print(' - - - - - - - - - -- - - -- - - - - - - - - - ')

soduku_printer(soduku)

print(loop)