from partitions import generate_alternate_nums_and_odds
from partitions import generate_sequence_of_position_numbers
from partitions import generate_alternate_symbols
from partitions import generate_sequence_of_symbols
from partitions import do_operation



def generate_primes(n):
    alter = generate_alternate_nums_and_odds(n)
    list_of_position_numbers = generate_sequence_of_position_numbers(n, alter)
    alter_symbols = generate_alternate_symbols(n)
    sequence_of_symbols = generate_sequence_of_symbols(n, list_of_position_numbers, alter_symbols)
    primes = []
    i = 2
    list_of_sum_of_factors = [2, 1]
    while len(primes) != n:
        next_sum_of_factors = 0
        if i == len(sequence_of_symbols):
            alter = generate_alternate_nums_and_odds(i*n)
            list_of_position_numbers = generate_sequence_of_position_numbers(i*n, alter)
            alter_symbols = generate_alternate_symbols(i*n)
            sequence_of_symbols = generate_sequence_of_symbols(i*n, list_of_position_numbers, alter_symbols)
        requried_symbols = sequence_of_symbols[:i]
        for j in range(i):
            if list(reversed(requried_symbols))[j] != 0:
                next_sum_of_factors= int(do_operation(next_sum_of_factors, list(reversed(requried_symbols))[j], list_of_sum_of_factors[j]))
            else:
                continue
        list_of_sum_of_factors.append(next_sum_of_factors)
        list_of_sum_of_factors[0] = list_of_sum_of_factors[0] + 1
        if list_of_sum_of_factors[0] == list_of_sum_of_factors[-1]:
            print('Generating next prime Number.........')
            print(f"{len(primes)}th prime calculated as {list_of_sum_of_factors[-1] - 1}")
            primes.append(list_of_sum_of_factors[-1] - 1)
        i = i+1
    print(f"THE FIRST {n} PRIMES WERE CALCULATED AS {primes}")
    return primes



primes = generate_primes(10000)

