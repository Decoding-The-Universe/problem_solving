def partitions(n):
        alter = generate_alternate_nums_and_odds(n)
        list_of_position_numbers = generate_sequence_of_position_numbers(n, alter)
        alter_symbols = generate_alternate_symbols(n)
        sequence_of_symbols = generate_sequence_of_symbols(n, list_of_position_numbers, alter_symbols)
        partitions = generate_partitions(n, sequence_of_symbols)
        print(partitions)
        print(f"And hence your result that is the number of partition for the number {n} are {partitions[-1]}, partition number is {list_of_position_numbers[-1]}")

def generate_alternate_nums_and_odds(n):

    alter = []
    for i in range(1, n):
        alter.append(i)
        alter.append(2*i+1)
    return alter

def generate_sequence_of_position_numbers(n, alter):
    
    list_of_position_numbers = [1]
    for i in range(n):
        list_of_position_numbers.append(list_of_position_numbers[i] + alter[i])
    return list_of_position_numbers

def generate_alternate_symbols(n):

    alter_symbols = []
    for i in range(n):
        alter_symbols.append('+')
        alter_symbols.append('+')
        alter_symbols.append('-')
        alter_symbols.append('-')
    return alter_symbols    

def generate_sequence_of_symbols(n, list_of_position_numbers ,alter_symbols):

    sequence_of_symbols = []
    k = 0
    for i in range(n):
        if i+1 in list_of_position_numbers:
            sequence_of_symbols.append(alter_symbols[k])
            k+=1
        else:
            sequence_of_symbols.append(0)
    return sequence_of_symbols

def generate_partitions(n, sequence_of_symbols):

    partitions = [1, 1]
    next_partition = 0
    for i in range(2, n):
        requried_symbols = sequence_of_symbols[:i]
        for j in range(i):
            if list(reversed(requried_symbols))[j] != 0:
                next_partition = int(do_operation(next_partition, list(reversed(requried_symbols))[j], partitions[j]))
            else:
                continue
        partitions.append(next_partition)
        next_partition = 0
        
    return partitions

def do_operation(left_term, symbol, right_term):

    if symbol == '+':
        return left_term + right_term

    else:
        return left_term - right_term

#partitions(666)